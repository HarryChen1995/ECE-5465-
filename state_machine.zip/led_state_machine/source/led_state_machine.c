
#include <stdio.h>
#include "board.h"
#include "peripherals.h"
#include "pin_mux.h"
#include "clock_config.h"
#include "MKL25Z4.h"
#include "fsl_debug_console.h"
#include "fsl_port.h"
#include "fsl_pit.h"

pit_config_t pitConfig;


gpio_pin_config_t config =
{
		kGPIO_DigitalOutput,
		0,
};



static void led_init(){


				CLOCK_EnableClock(kCLOCK_PortB);
			    PORT_SetPinMux(PORTB, 8u, kPORT_MuxAsGpio);
			    PORT_SetPinMux(PORTB, 9u, kPORT_MuxAsGpio);
			    PORT_SetPinMux(PORTB, 10u, kPORT_MuxAsGpio);
			    GPIO_PinInit(GPIOB,8u,&config);
			    GPIO_PinInit(GPIOB,9u,&config);
			    GPIO_PinInit(GPIOB,10u,&config);



}


static void led1_on(){
	GPIO_WritePinOutput(GPIOB,8u,1);
}


static void led1_off(){
	GPIO_WritePinOutput(GPIOB,8u,0);
}

static void led2_on(){
	GPIO_WritePinOutput(GPIOB,9u,1);
}


static void led2_off(){
	GPIO_WritePinOutput(GPIOB,9u,0);
}

static void led3_on(){
	GPIO_WritePinOutput(GPIOB,10u,1);
}


static void led3_off(){
	GPIO_WritePinOutput(GPIOB,10u,0);
}


enum states {

	led1,
	led2,
	led3


};


volatile enum states state = led1;




static void PIT_enable(){


	 PIT_GetDefaultConfig(&pitConfig);
	 PIT_Init(PIT, &pitConfig);
	 PIT_SetTimerPeriod(PIT, kPIT_Chnl_0, USEC_TO_COUNT(1000000U, CLOCK_GetFreq(kCLOCK_BusClk)));
	 PIT_EnableInterrupts(PIT, kPIT_Chnl_0, kPIT_TimerInterruptEnable);
	 EnableIRQ(PIT_IRQn);
	 PIT_StartTimer(PIT, kPIT_Chnl_0);







}

static void delay(){

	int i = 600000;

	while(i--);

}

int main(void) {


    BOARD_InitPins();
    BOARD_BootClockRUN();
    BOARD_InitDebugConsole();


   led_init();

   PIT_enable();

    while(1){


			  switch(state){

			  case led1:
				  led1_on();
				  led2_off();
				  led3_off();
				  break;
			  case led2:
				  led1_off();
				  led2_on();
				  led3_off();
				  break;
			  case led3:
				  led1_off();
				  led2_off();
				  led3_on();
				  break;




			  }


    }

   return 0;
}



void PIT_IRQHandler(){

	 PIT_ClearStatusFlags(PIT, kPIT_Chnl_0, kPIT_TimerFlag);


	 if(state == led1){
	 	state = led2;
	 }

	 else if (state == led2){
	 	state =led3;
	 }

	 else {
	 	state = led1;
	 }



}

